*{
    margin: 0;
    padding: 0;
}
body{
    position: absolute;
left: 1.91%;
right: 1.81%;
top: 19.29%;
bottom: 2.31%;

background: #9C1801;
filter: blur(20px);
border-radius: 29px;

}

.logo{
    position: absolute;
width: 266px;
height: 116.51px;
left: 29px;
top: 13px;
}

.t1{
    position: absolute;
left: 64.69%;
right: 8.46%;
top: 25.24%;
bottom: 38.56%;

background: url(mcgonagall.png);
filter: drop-shadow(4px 4px 30px rgba(0, 0, 0, 0.25));
border-radius: 21px;
}